Codecov Extension
=================
> Overlay reports directly into Github and Bitbucket to streamline your workflow.

[![video][10]][11]


## Choose your browser below

|     **Chrome**    |    **Firefox**     |     **Opera**     |     **Safari**    |     **IE**    |
| ----------------- | ------------------ | ----------------- | ----------------- | ------------- |
| [![chrome][0]][1] | [![firefox][2]][3] | [![opera][4]][5]  | [![safari][6]][7] | [![ie][8]][9] |
| **Now Available** | **Now Available**  | **Now Available** | `planned`         | `planned`     |



[0]: http://www.iconarchive.com/download/i38830/google/chrome/Google-Chrome.ico "Review and install for Chrome"
[1]: https://chrome.google.com/webstore/detail/codecov-extension/keefkhehidemnokodkdkejapdgfjmijf
[2]: http://www.iconarchive.com/download/i51115/hopstarter/software/Mozilla-Firefox.ico "Review and install for Firefox"
[3]: https://addons.mozilla.org/en-US/firefox/addon/codecov-extension
[4]: https://cdn1.iconfinder.com/data/icons/android-png/256/Android-Opera-Mini.png  "Review and install for Opera"
[5]: https://addons.opera.com/en/extensions/details/codecov-extension
[6]: http://icons.iconarchive.com/icons/kyo-tux/aeon/256/Apps-Safari-icon.png "Help wanted"
[7]: https://github.com/codecov/browser-extension/issues/14
[8]: http://www.iconarchive.com/download/i45866/tatice/cristal-intense/Internet-Explorer.ico "Help wanted"
[9]: https://github.com/codecov/browser-extension/issues/15

[10]: https://cloud.githubusercontent.com/assets/2041757/9814630/7c8847d0-585d-11e5-887b-b5a19170ef61.png "Watch how on YouTube"
[11]: https://www.youtube.com/watch?v=d6wJKODB8_g
